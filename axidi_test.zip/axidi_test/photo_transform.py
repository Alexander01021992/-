"""
Улучшенный модуль для генерации изображений по одному фото через Replicate API
PixelPie AI - Фото Преображение
"""

import replicate
import asyncio
import aiohttp
import os
import logging
from typing import Optional, Dict, Any, Union, List
from datetime import datetime

logger = logging.getLogger(__name__)

class PhotoTransformGenerator:
    """Класс для генерации изображений по одному фото через Replicate"""
    
    def __init__(self, replicate_api_key: str):
        """
        Инициализация генератора
        
        Args:
            replicate_api_key: API ключ для Replicate
        """
        self.api_key = replicate_api_key
        os.environ["REPLICATE_API_TOKEN"] = replicate_api_key
        
        # Стили генерации с промптами для runwayml/gen4-image
        self.styles = {
            "photoshop": {
                "name": "🤍 Фотошоп",
                "description": "Улучшение качества без изменений",
                "prompt_template": "Professional portrait photo of @person, enhanced quality, clean background, natural colors, perfect lighting, photorealistic, ultra-detailed, 8K resolution",
                "model": "runwayml/gen4-image",
                "model_type": "gen4",
                "aspect_ratio": "3:4"
            },
            "art": {
                "name": "🎨 AI Art",
                "description": "Иллюстрация в авторском стиле",
                "prompt_template": "Digital art illustration of @person, artistic style, pastel colors, creative portrait, Pinterest aesthetic, beautiful lighting, stylized",
                "model": "runwayml/gen4-image",
                "model_type": "gen4",
                "aspect_ratio": "3:4"
            },
            "cinema": {
                "name": "🎬 Кино",
                "description": "Кадр из художественного фильма",
                "prompt_template": "Cinematic portrait of @person, movie scene, dramatic lighting, film grain, atmospheric colors, professional cinematography",
                "model": "runwayml/gen4-image",
                "model_type": "gen4",
                "aspect_ratio": "3:4"
            },
            "portrait": {
                "name": "🧠 Портрет",
                "description": "Глубокий психологический образ",
                "prompt_template": "Deep psychological portrait of @person, soft shadows, face focus, character photography, soulful expression, professional photographer style",
                "model": "runwayml/gen4-image",
                "model_type": "gen4",
                "aspect_ratio": "3:4"
            },
            "fantasy": {
                "name": "⚡ Фантастика",
                "description": "Неон, sci-fi, визуальный драйв",
                "prompt_template": "Cyberpunk portrait of @person, neon lights, sci-fi style, futuristic, glitch effects, dramatic lighting, cosmic atmosphere",
                "model": "runwayml/gen4-image",
                "model_type": "gen4",
                "aspect_ratio": "3:4"
            },
            "lego": {
                "name": "🧱 LEGO",
                "description": "Превращение в LEGO минифигурку",
                "prompt_template": "A hyper-detailed LEGO minifigure of @person, ultra-realistic LEGO style, 4K resolution, vibrant colors, precise blocky textures, LEGO hair with stud details, glossy LEGO pieces, visible brick seams, LEGO cityscape background, cinematic lighting, plastic sheen, blocky toy-like nature, perfect LEGO brick alignment, stud patterns, reflective plastic surfaces",
                "model": "runwayml/gen4-image",
                "model_type": "gen4",
                "aspect_ratio": "3:4"
            }
        }
        
        # Клиент Replicate
        self.client = replicate.Client(api_token=replicate_api_key)
    
    async def generate_image(self, image_url: str, style: str, user_id: int) -> Dict[str, Any]:
        """
        Генерация изображения в выбранном стиле
        
        Args:
            image_url: URL исходного изображения
            style: Выбранный стиль генерации
            user_id: ID пользователя
            
        Returns:
            Словарь с результатами генерации
        """
        try:
            logger.info(f"Начало генерации для пользователя {user_id} в стиле {style}")
            
            if style not in self.styles:
                raise ValueError(f"Неизвестный стиль: {style}")
            
            style_config = self.styles[style]
            
            # Параметры для модели runwayml/gen4-image
            input_params = {
                "prompt": style_config['prompt_template'],
                "aspect_ratio": style_config['aspect_ratio'],
                "reference_tags": ["person"],
                "reference_images": [image_url]
            }
            
            # Создаем prediction через API
            logger.info(f"Создание prediction для модели {style_config['model']}")
            
            prediction = await asyncio.to_thread(
                self.client.predictions.create,
                model=style_config['model'],
                input=input_params
            )
            
            logger.info(f"Prediction создан: {prediction.id}")
            
            # Ждем завершения
            while prediction.status not in ["succeeded", "failed", "canceled"]:
                await asyncio.sleep(2)
                prediction = await asyncio.to_thread(
                    self.client.predictions.get,
                    prediction.id
                )
                logger.info(f"Статус: {prediction.status}")
            
            if prediction.status == "succeeded":
                # Получаем URL напрямую из output
                output_url = prediction.output
                
                # Логируем тип для отладки
                logger.info(f"Тип output: {type(output_url)}")
                logger.info(f"Output значение: {output_url}")
                
                # Если это строка - отлично, используем как есть
                if isinstance(output_url, str):
                    result_url = output_url
                # Если это FileOutput, пробуем получить URL
                elif hasattr(output_url, 'url'):
                    result_url = output_url.url
                # Если это FileOutput без url, но со строковым представлением
                elif hasattr(output_url, '__str__'):
                    result_url = str(output_url)
                else:
                    # Последняя попытка - проверяем атрибуты
                    logger.error(f"Неизвестный тип output: {type(output_url)}")
                    if hasattr(output_url, '__dict__'):
                        logger.error(f"Атрибуты: {output_url.__dict__}")
                    raise ValueError(f"Не удалось получить URL из output: {type(output_url)}")
                
                logger.info(f"Генерация завершена успешно, URL: {result_url}")
                
                return {
                    "success": True,
                    "result_url": result_url,
                    "style": style,
                    "style_name": style_config['name'],
                    "timestamp": datetime.now().isoformat(),
                    "prediction_id": prediction.id
                }
            else:
                error_msg = f"Генерация завершилась со статусом: {prediction.status}"
                if hasattr(prediction, 'error') and prediction.error:
                    error_msg += f" - {prediction.error}"
                
                logger.error(f"Ошибка генерации: {error_msg}")
                
                return {
                    "success": False,
                    "error": error_msg,
                    "style": style,
                    "timestamp": datetime.now().isoformat()
                }
                
        except Exception as e:
            logger.error(f"Ошибка генерации для пользователя {user_id}: {str(e)}")
            return {
                "success": False,
                "error": str(e),
                "style": style,
                "timestamp": datetime.now().isoformat()
            }
    
    async def download_image(self, url: str) -> bytes:
        """
        Скачивание изображения по URL
        
        Args:
            url: URL изображения
            
        Returns:
            Байты изображения
        """
        try:
            timeout = aiohttp.ClientTimeout(total=60)
            async with aiohttp.ClientSession(timeout=timeout) as session:
                async with session.get(url) as response:
                    if response.status == 200:
                        return await response.read()
                    else:
                        raise Exception(f"Ошибка загрузки изображения: HTTP {response.status}")
        except Exception as e:
            logger.error(f"Ошибка при скачивании изображения: {str(e)}")
            raise
    
    def get_style_keyboard(self) -> List[List[Dict[str, str]]]:
        """
        Получение клавиатуры со стилями для inline-кнопок
        
        Returns:
            Список кнопок для InlineKeyboardMarkup
        """
        keyboard = []
        
        # Группируем кнопки по 2 в ряд
        row = []
        for style_key, style_info in self.styles.items():
            button_data = {
                "text": style_info["name"],
                "callback_data": f"transform_style:{style_key}"
            }
            row.append(button_data)
            
            if len(row) == 2:
                keyboard.append(row)
                row = []
        
        # Добавляем оставшиеся кнопки
        if row:
            keyboard.append(row)
        
        # Добавляем кнопку отмены
        keyboard.append([{"text": "❌ Отменить", "callback_data": "transform_cancel"}])
        
        return keyboard
    
    def get_style_info(self, style: str) -> Optional[Dict[str, str]]:
        """
        Получение информации о стиле
        
        Args:
            style: Ключ стиля
            
        Returns:
            Информация о стиле или None
        """
        return self.styles.get(style)
    
    def get_style_description(self, style: str) -> str:
        """
        Получение полного описания стиля
        
        Args:
            style: Ключ стиля
            
        Returns:
            Текстовое описание стиля
        """
        descriptions = {
            "photoshop": """🤍 Фотошоп / Улучшение

Ты — как есть, но в идеальном свете.
Фон вычищен, кожа выглядит свежо, цвета — естественные.
Как будто твое фото ретушировал профи. Без лишних фильтров.

📌 Подходит для: аватарки, резюме, профиля.
⚡ PixelPie AI улучшит качество с помощью нейросети""",
            
            "art": """🎨 AI Art / Иллюстрация

Фото превращается в арт.
Линии, свет, пастель или стиль digital-иллюстраций — и ты выглядишь как персонаж книги или Pinterest-постера.

📌 Подходит для: творчества, сторис, эстетичного контента.
🎨 PixelPie AI создаст уникальную иллюстрацию""",
            
            "cinema": """🎬 Кино / Cinematic

Ты в кадре — будто это сцена из фильма.
Атмосферные цвета, направленный свет и немного драмы.

📌 Подходит для: ярких образов, вау-эффекта, постов с настроением.
🎥 PixelPie AI применит кинематографическую обработку""",
            
            "portrait": """🧠 Портрет / Психологический

Глубокий взгляд, мягкие тени, фокус на лице.
Эффект, как будто ты снят фотографом, который умеет показать характер.

📌 Подходит для: спокойных аватарок, презентаций, контента с душой.
📸 PixelPie AI создаст профессиональный портрет""",
            
            "fantasy": """⚡ Фантастика / Neon-Cyber

Ты в другом времени, в другой вселенной.
Глитчи, неон, драматичный свет — визуальный экшн прямо из sci-fi трейлера.

📌 Подходит для: аватарок, сторис, ярких постов.
🚀 PixelPie AI перенесет тебя в будущее""",
            
            "lego": """🧱 LEGO / Минифигурка

Превращение в детализированную LEGO минифигурку.
Яркие цвета, блочные текстуры, культовый стиль конструктора.
Каждая деталь проработана до мельчайших кубиков!

📌 Подходит для: веселых аватарок, подарков, креативного контента.
🧱 PixelPie AI создаст твою уникальную LEGO-версию"""
        }
        
        return descriptions.get(style, "Описание недоступно")