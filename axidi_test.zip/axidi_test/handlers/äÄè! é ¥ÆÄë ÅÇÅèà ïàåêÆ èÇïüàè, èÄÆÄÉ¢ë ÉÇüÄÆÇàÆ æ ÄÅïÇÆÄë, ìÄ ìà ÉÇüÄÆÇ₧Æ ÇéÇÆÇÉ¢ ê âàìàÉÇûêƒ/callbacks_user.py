import asyncio
import logging
import os
from typing import Optional
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ConversationHandler, CallbackQueryHandler
from telegram.constants import ParseMode
from datetime import datetime, timedelta
from config import (
    ADMIN_IDS, TARIFFS, IMAGE_GENERATION_MODELS, GENERATION_STYLES,
    NEW_MALE_AVATAR_STYLES, NEW_FEMALE_AVATAR_STYLES, style_prompts,
    new_male_avatar_prompts, new_female_avatar_prompts
)
from database import (
    check_subscription, update_resources, add_rating, get_user_trainedmodels,
    get_active_trainedmodel, delete_trained_model, get_user_video_tasks,
    get_user_rating_and_registration, get_user_generation_stats, get_user_payments, is_user_blocked
)
from keyboards import (
    create_main_menu_keyboard, create_subscription_keyboard,
    create_user_profile_keyboard, create_generate_menu_keyboard,
    create_aspect_ratio_keyboard, create_avatar_selection_keyboard,
    create_training_keyboard, create_prompt_selection_keyboard,
    create_avatar_style_choice_keyboard, create_new_male_avatar_styles_keyboard,
    create_new_female_avatar_styles_keyboard, create_confirmation_keyboard,
    create_back_keyboard, create_referral_keyboard
)
from handlers.user_management import (
    show_user_actions, show_user_profile_admin, show_user_avatars_admin,
    change_balance_admin, show_user_logs, delete_user_admin, confirm_delete_user,
    block_user_admin, confirm_block_user, is_user_blocked
)
from generation import reset_generation_context, generate_image, start_training, handle_generate_video, check_training_status
from handlers.utils import (
    safe_escape_markdown as escape_md, send_message_with_fallback, safe_answer_callback,
    check_resources, check_active_avatar, check_style_config, create_payment_link,
    get_tariff_text, send_typing_action
)

logger = logging.getLogger(__name__)

# Состояния для FSM
(AWAITING_BROADCAST_MESSAGE, AWAITING_BROADCAST_CONFIRM, AWAITING_PAYMENT_DATES,
 AWAITING_USER_SEARCH, AWAITING_BALANCE_CHANGE, AWAITING_BROADCAST_FILTERS,
 AWAITING_BROADCAST_SCHEDULE, AWAITING_ACTIVITY_DATES) = range(8)

async def button(update: Update, context: ContextTypes.DEFAULT_TYPE) -> Optional[int]:
    """Основной обработчик всех callback-кнопок."""
    query = update.callback_query
    user_id = update.effective_user.id

    if not query:
        logger.warning(f"button вызван без callback_query для user_id={user_id}")
        return None

    # Проверяем блокировку пользователя
    if await is_user_blocked(user_id):
        await query.answer("🚫 Ваш аккаунт заблокирован.", show_alert=True)
        await send_message_with_fallback(
            context.bot, user_id,
            escape_md("🚫 Ваш аккаунт заблокирован. Обратитесь в поддержку: @AXIDI_Help"),
            update_or_query=update,
            parse_mode=ParseMode.MARKDOWN_V2
        )
        logger.info(f"Заблокированный пользователь user_id={user_id} пытался выполнить callback: {query.data}")
        return None

    await query.answer()
    callback_data = query.data
    logger.info(f"Callback от user_id={user_id}: {callback_data}")

    bot = context.bot
    context._user_id = user_id

    try:
        # Делегирование обработки в зависимости от типа callback
        if callback_data.startswith("admin_") or callback_data.startswith("user_") or callback_data.startswith("payments_") or \
           callback_data.startswith("visualize_") or callback_data.startswith("confirm_") or callback_data.startswith("reset_") or \
           callback_data.startswith("broadcast_"):
            from handlers.callbacks_admin import handle_admin_callback
            return await handle_admin_callback(update, context)
        elif callback_data.startswith("referral") or callback_data == "my_referrals":
            from handlers.callbacks_referrals import handle_referrals_callback
            await handle_referrals_callback(update, context)
            return None
        else:
            await handle_user_callback(update, context)
            return None

    except Exception as e:
        logger.error(f"Ошибка в обработчике callback для user_id={user_id}, data={callback_data}: {e}", exc_info=True)
        await send_message_with_fallback(
            bot,
            user_id,
            escape_md("❌ Произошла ошибка. Попробуйте снова или обратитесь в поддержку."),
            update_or_query=update,
            reply_markup=await create_main_menu_keyboard(user_id),
            parse_mode=ParseMode.MARKDOWN_V2
        )

async def handle_user_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> Optional[int]:
    """Обрабатывает callback-запросы пользовательского интерфейса."""
    query = update.callback_query
    user_id = query.from_user.id
    await query.answer()

    if await is_user_blocked(user_id):
        await query.answer("🚫 Ваш аккаунт заблокирован.", show_alert=True)
        await send_message_with_fallback(
            context.bot, user_id,
            escape_md("🚫 Ваш аккаунт заблокирован. Обратитесь в поддержку: @AXIDI_Help"),
            update_or_query=update,
            parse_mode=ParseMode.MARKDOWN_V2
        )
        logger.info(f"Заблокированный пользователь user_id={user_id} пытался выполнить callback: {query.data}")
        return

    callback_data = query.data
    logger.info(f"Callback от user_id={user_id}: {callback_data}")

    try:
        # === ОСНОВНОЙ ФУНКЦИОНАЛ ГЕНЕРАЦИИ ===
        if callback_data == "proceed_to_payment":
            await handle_proceed_to_payment_callback(query, context, user_id)
        elif callback_data == "generate_menu":
            await handle_generate_menu_callback(query, context, user_id)
        elif callback_data == "generate_with_avatar":
            await handle_generate_with_avatar_callback(query, context, user_id)
        elif callback_data == "photo_to_photo":
            await handle_photo_to_photo_callback(query, context, user_id)
        elif callback_data in ["ai_video", "ai_video_v2"]:
            await handle_ai_video_callback(query, context, user_id, callback_data)
        elif callback_data == "repeat_last_generation":
            await handle_repeat_last_generation_callback(query, context, user_id)
        elif callback_data in ["select_generic_avatar_styles", "select_new_male_avatar_styles", "select_new_female_avatar_styles"]:
            await handle_style_selection_callback(query, context, user_id, callback_data)
        elif callback_data.startswith("style_"):
            await handle_style_choice_callback(query, context, user_id, callback_data)
        elif callback_data.startswith("male_styles_page_"):
            page = int(callback_data.split("_")[-1])
            await handle_male_styles_page_callback(query, context, user_id, page)
        elif callback_data.startswith("female_styles_page_"):
            page = int(callback_data.split("_")[-1])
            await handle_female_styles_page_callback(query, context, user_id, page)
        elif callback_data == "page_info":
            await safe_answer_callback(query, "Используйте кнопки навигации для перехода между страницами")
        elif callback_data == "enter_custom_prompt_manual":
            await handle_custom_prompt_manual_callback(query, context, user_id)
        elif callback_data == "enter_custom_prompt_llama":
            await handle_custom_prompt_llama_callback(query, context, user_id)
        elif callback_data == "confirm_assisted_prompt":
            await handle_confirm_assisted_prompt_callback(query, context, user_id)
        elif callback_data == "edit_assisted_prompt":
            await handle_edit_assisted_prompt_callback(query, context, user_id)
        elif callback_data == "skip_prompt":
            await handle_skip_prompt_callback(query, context, user_id)
        elif callback_data.startswith("aspect_"):
            await handle_aspect_ratio_callback(query, context, user_id, callback_data)
        elif callback_data == "aspect_ratio_info":
            await handle_aspect_ratio_info_callback(query, context, user_id)
        elif callback_data == "back_to_aspect_selection":
            await handle_back_to_aspect_selection_callback(query, context, user_id)
        elif callback_data == "back_to_style_selection":
            await handle_back_to_style_selection_callback(query, context, user_id)
        elif callback_data == "confirm_generation":
            await handle_confirm_generation_callback(query, context, user_id, update)
        elif callback_data == "confirm_photo_quality":
            await handle_confirm_photo_quality_callback(query, context, user_id, update)
        elif callback_data == "skip_mask":
            await handle_skip_mask_callback(query, context, user_id)

        # === ОЦЕНКА И РЕЙТИНГ ===
        elif callback_data.startswith("rate_"):
            await handle_rating_callback(query, context, user_id, callback_data)

        # === ПРОФИЛЬ И ПОДПИСКА ===
        elif callback_data == "user_profile":
            await handle_user_profile_callback(query, context, user_id)
        elif callback_data == "check_subscription":
            await handle_check_subscription_callback(query, context, user_id)
        elif callback_data == "user_stats":
            await handle_user_stats_callback(query, context, user_id)
        elif callback_data == "subscribe":
            await handle_subscribe_callback(query, context, user_id)
        elif callback_data.startswith("pay_"):
            await handle_payment_callback(query, context, user_id, callback_data)
        elif callback_data == "change_email":
            await handle_change_email_callback(query, context, user_id)
        elif callback_data == "confirm_change_email":
            await handle_confirm_change_email_callback(query, context, user_id)

        # === АВАТАРЫ ===
        elif callback_data == "my_avatars":
            await handle_my_avatars_callback(query, context, user_id)
        elif callback_data.startswith("select_avatar_"):
            await handle_select_avatar_callback(query, context, user_id, callback_data)
        elif callback_data == "train_flux":
            await handle_train_flux_callback(query, context, user_id)
        elif callback_data == "continue_upload":
            await handle_continue_upload_callback(query, context, user_id)
        elif callback_data == "start_training":
            await handle_start_training_callback(query, context, user_id, update)
        elif callback_data == "confirm_start_training":
            await handle_confirm_start_training_callback(query, context, user_id, update)
        elif callback_data == "back_to_avatar_name_input":
            await handle_back_to_avatar_name_callback(query, context, user_id)
        elif callback_data.startswith("use_suggested_trigger_"):
            await handle_use_suggested_trigger_callback(query, context, user_id, callback_data)
        elif callback_data == "check_training":
            from handlers.commands import check_training
            await check_training(update, context)

    except Exception as e:
        logger.error(f"Ошибка в обработчике callback для user_id={user_id}, data={callback_data}: {e}", exc_info=True)
        await send_message_with_fallback(
            context.bot, user_id,
            escape_md("❌ Произошла ошибка. Попробуйте снова или обратитесь в поддержку."),
            update_or_query=update,
            reply_markup=await create_main_menu_keyboard(user_id),
            parse_mode=ParseMode.MARKDOWN_V2
        )

async def handle_proceed_to_payment_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Обработка перехода к оплате из приветствия."""
    subscription_data = await check_subscription(user_id)
    first_purchase = bool(subscription_data[5]) if subscription_data and len(subscription_data) > 5 else True
    tariff_text = get_tariff_text(first_purchase)
    subscription_kb = await create_subscription_keyboard()
    await send_message_with_fallback(
        context.bot, user_id, tariff_text, update_or_query=query,
        reply_markup=subscription_kb, parse_mode=ParseMode.MARKDOWN_V2
    )

async def delete_all_videos(context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Удаляет все видео (меню и генерации), если они есть."""
    if 'menu_video_message_id' in context.user_data:
        try:
            await context.bot.delete_message(chat_id=user_id, message_id=context.user_data['menu_video_message_id'])
            context.user_data.pop('menu_video_message_id', None)
        except Exception as e:
            logger.debug(f"Не удалось удалить видео меню: {e}")
    if 'generation_video_message_id' in context.user_data:
        try:
            await context.bot.delete_message(chat_id=user_id, message_id=context.user_data['generation_video_message_id'])
            context.user_data.pop('generation_video_message_id', None)
        except Exception as e:
            logger.debug(f"Не удалось удалить видео генерации: {e}")

async def handle_generate_menu_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Обработка меню генерации."""
    await delete_all_videos(context, user_id)
    text = (
        "✨ Выбери, что хочешь создать:\n\n"
        "📸 Фотосессия с аватаром\n"
        "Создай уникальные фото с твоим личным AI-аватаром. "
        "Выбери стиль и получи профессиональные снимки за секунды!\n\n"
        "🖼 Фото по референсу\n"
        "Загрузи любое фото и преврати его в шедевр с твоим аватаром. "
        "Идеально для воссоздания понравившихся образов!\n\n"
        "🎬 AI-видео\n"
        "Оживи статичное изображение! Превращаем фото в короткое "
        "динамичное видео с реалистичными движениями."
    )
    generation_video_path = "images/generation.mp4"
    try:
        if os.path.exists(generation_video_path):
            with open(generation_video_path, "rb") as video_file:
                video_message = await context.bot.send_video(
                    chat_id=user_id, video=video_file,
                    caption=escape_md(text),
                    reply_markup=await create_generate_menu_keyboard(),
                    parse_mode=ParseMode.MARKDOWN_V2
                )
                context.user_data['generation_video_message_id'] = video_message.message_id
        else:
            logger.warning(f"Видео генерации не найдено по пути: {generation_video_path}")
            await send_message_with_fallback(
                context.bot, user_id, escape_md(text), update_or_query=query,
                reply_markup=await create_generate_menu_keyboard(),
                parse_mode=ParseMode.MARKDOWN_V2
            )
    except Exception as e:
        logger.error(f"Не удалось отправить видео генерации для user_id={user_id}: {e}")
        await send_message_with_fallback(
            context.bot, user_id, escape_md(text), update_or_query=query,
            reply_markup=await create_generate_menu_keyboard(),
            parse_mode=ParseMode.MARKDOWN_V2
        )

async def handle_generate_with_avatar_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Обработка генерации с аватаром."""
    await delete_all_videos(context, user_id)
    if not await check_active_avatar(context, user_id):
        return
    if not await check_resources(context, user_id, required_photos=2):
        return
    context.user_data['generation_type'] = 'with_avatar'
    context.user_data['model_key'] = "flux-trained"
    text = escape_md("👤 Выбери категорию стилей для генерации с аватаром:")
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=await create_avatar_style_choice_keyboard(),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_style_selection_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, callback_data: str) -> None:
    """Обработка выбора категории стилей."""
    if callback_data == "select_generic_avatar_styles":
        context.user_data['current_style_set'] = 'generic_avatar'
        keyboard = InlineKeyboardMarkup([
            [InlineKeyboardButton("👨 Мужские стили", callback_data="select_new_male_avatar_styles")],
            [InlineKeyboardButton("👩 Женские стили", callback_data="select_new_female_avatar_styles")],
            [InlineKeyboardButton("✍️ Свой промпт", callback_data="custom_prompt_for_avatar")],
            [InlineKeyboardButton("🔙 Назад", callback_data="generate_with_avatar")]
        ])
        text = escape_md("👤 Выбери категорию стилей для генерации с аватаром:")
    elif callback_data == "select_new_male_avatar_styles":
        context.user_data['current_style_set'] = 'new_male_avatar'
        context.user_data['selected_gender'] = 'man'
        if not check_style_config('new_male_avatar'):
            await send_message_with_fallback(
                context.bot, user_id,
                escape_md("❌ Ошибка конфигурации мужских стилей. Обратитесь к администратору."),
                update_or_query=query,
                reply_markup=await create_main_menu_keyboard(user_id),
                parse_mode=ParseMode.MARKDOWN_V2
            )
            return
        keyboard = await create_new_male_avatar_styles_keyboard(page=1)
        text = escape_md("👨 Выбери мужской стиль или введи свой промпт:")
    elif callback_data == "select_new_female_avatar_styles":
        context.user_data['current_style_set'] = 'new_female_avatar'
        context.user_data['selected_gender'] = 'woman'
        if not check_style_config('new_female_avatar'):
            await send_message_with_fallback(
                context.bot, user_id,
                escape_md("❌ Ошибка конфигурации женских стилей. Обратитесь к администратору."),
                update_or_query=query,
                reply_markup=await create_main_menu_keyboard(user_id),
                parse_mode=ParseMode.MARKDOWN_V2
            )
            return
        keyboard = await create_new_female_avatar_styles_keyboard(page=1)
        text = escape_md("👩 Выбери женский стиль или введи свой промпт:")
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_style_choice_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, callback_data: str) -> None:
    """Обработка выбора конкретного стиля."""
    logger.debug(f"handle_style_choice: callback_data = {callback_data}")
    if callback_data.startswith("style_generic_"):
        style_key = callback_data.replace("style_generic_", "")
        prompt = style_prompts.get(style_key)
        style_name = GENERATION_STYLES.get(style_key, style_key)
        logger.debug(f"Generic style: key={style_key}, name={style_name}")
    elif callback_data.startswith("style_new_male_"):
        style_key = callback_data.replace("style_new_male_", "")
        prompt = new_male_avatar_prompts.get(style_key)
        style_name = NEW_MALE_AVATAR_STYLES.get(style_key, style_key)
        logger.debug(f"Male style: key={style_key}, name={style_name}")
    elif callback_data.startswith("style_new_female_"):
        style_key = callback_data.replace("style_new_female_", "")
        prompt = new_female_avatar_prompts.get(style_key)
        style_name = NEW_FEMALE_AVATAR_STYLES.get(style_key, style_key)
        logger.debug(f"Female style: key={style_key}, name={style_name}")
    else:
        logger.error(f"Неизвестный формат callback_data для стиля: {callback_data}")
        await send_message_with_fallback(
            context.bot, user_id,
            escape_md("❌ Ошибка выбора стиля. Попробуйте еще раз."),
            update_or_query=query,
            reply_markup=await create_generate_menu_keyboard(),
            parse_mode=ParseMode.MARKDOWN_V2
        )
        return
    if not prompt:
        logger.error(f"Промпт не найден для стиля '{style_key}'")
        await send_message_with_fallback(
            context.bot, user_id,
            escape_md(f"❌ Промпт для стиля '{style_name}' не найден."),
            update_or_query=query,
            reply_markup=await create_generate_menu_keyboard(),
            parse_mode=ParseMode.MARKDOWN_V2
        )
        return
    context.user_data['prompt'] = prompt
    logger.info(f"Выбран стиль '{style_name}' для user_id={user_id}")
    await send_message_with_fallback(
        context.bot, user_id,
        escape_md(f"✅ Выбран стиль: {style_name}"),
        update_or_query=query,
        parse_mode=ParseMode.MARKDOWN_V2
    )
    await ask_for_aspect_ratio_callback(query, context)

async def handle_male_styles_page_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, page: int) -> None:
    """Обработка перехода на страницу мужских стилей."""
    context.user_data['current_style_set'] = 'new_male_avatar'
    context.user_data['selected_gender'] = 'man'
    keyboard = await create_new_male_avatar_styles_keyboard(page)
    text = escape_md("👨 Выбери мужской стиль или введи свой промпт:")
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_female_styles_page_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, page: int) -> None:
    """Обработка перехода на страницу женских стилей."""
    context.user_data['current_style_set'] = 'new_female_avatar'
    context.user_data['selected_gender'] = 'woman'
    keyboard = await create_new_female_avatar_styles_keyboard(page)
    text = escape_md("👩 Выбери женский стиль или введи свой промпт:")
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_photo_to_photo_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Обработка photo-to-photo генерации."""
    await delete_all_videos(context, user_id)
    if not await check_active_avatar(context, user_id):
        return
    if not await check_resources(context, user_id, required_photos=2):
        return
    reset_generation_context(context, "photo_to_photo", partial=True)
    context.user_data['generation_type'] = 'photo_to_photo'
    context.user_data['model_key'] = "flux-trained"
    context.user_data['waiting_for_photo'] = True
    text = (
        "🖼Фото по референсу\n\n"
        "Загрузи фото-референс, которое хочешь воспроизвести с твоим аватаром. "
        "📝PixelPie Ai создаст твое фото сам!."
    )
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад", callback_data="generate_menu")]]),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_ai_video_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, callback_data: str) -> None:
    """Обработка генерации AI видео."""
    if callback_data == "ai_video_v2":
        model_key = "kwaivgi/kling-v2.0"
        required_photos = 30
        generation_type = "ai_video_v2"
    else:
        model_key = "kwaivgi/kling-v1.6-pro"
        required_photos = 20
        generation_type = "ai_video"
    if not await check_resources(context, user_id, required_photos=required_photos):
        return
    reset_generation_context(context, generation_type)
    context.user_data['generation_type'] = generation_type
    context.user_data['model_key'] = model_key
    context.user_data['video_cost'] = required_photos
    context.user_data['waiting_for_video_prompt'] = True
    model_name = IMAGE_GENERATION_MODELS.get(model_key, {}).get('name', 'AI-Видео')
    text = (
        f"🎬 {model_name}\n\n"
        f"Для создания видео потребуется *{required_photos} фото* с твоего баланса.\n\n"
        "Для начала давай придумаем описание, что будет происходить на видео, "
        "после чего ты сможешь добавить фото, взятое за основу.\n\n"
        "📝 1. Опишите, какое движение или действие должно происходить в видео:\n\n"
        "_Например: камера медленно приближается к объекту, "
        "человек поворачивает голову и улыбается, "
        "дым плавно поднимается вверх_"
    )
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Отмена", callback_data="generate_menu")]]),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_custom_prompt_manual_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Ручной ввод промпта."""
    context.user_data['waiting_for_custom_prompt_manual'] = True
    context.user_data['came_from_custom_prompt'] = True
    text = escape_md("✍️ Введи свой промпт (описание того, что хочешь увидеть на фото):")
    back_callback = "back_to_style_selection" if context.user_data.get('generation_type') != 'photo_to_photo' else "photo_to_photo"
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад", callback_data=back_callback)]]),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_custom_prompt_llama_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Ввод идеи для AI помощника с генерацией с аватаром."""
    if not await check_active_avatar(context, user_id):
        return
    context.user_data['waiting_for_custom_prompt_llama'] = True
    context.user_data['generation_type'] = 'with_avatar'
    context.user_data['use_llama_prompt'] = True
    text = (
        "🤖 AI-помощник поможет создать детальный промпт для генерации с твоим аватаром!\n\n"
        "Опиши свою идею простыми словами, а я превращу её в профессиональный промпт.\n\n"
        "Например: _\"деловой человек в офисе\"_ или _\"девушка на пляже на закате\"_"
    )
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад", callback_data="back_to_style_selection")]]),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_confirm_assisted_prompt_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Подтверждение промпта от AI помощника."""
    context.user_data['model_key'] = "flux-trained"
    context.user_data['generation_type'] = 'with_avatar'
    await send_message_with_fallback(
        context.bot, user_id,
        escape_md("✅ Промпт подтвержден! Выбери соотношение сторон:"),
        update_or_query=query,
        reply_markup=await create_aspect_ratio_keyboard(),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_edit_assisted_prompt_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Редактирование промпта от AI помощника."""
    context.user_data['waiting_for_custom_prompt_manual'] = True
    context.user_data['came_from_custom_prompt'] = True
    context.user_data.pop('user_input_for_llama', None)
    current_prompt = context.user_data.get('prompt', '')
    text = (
        f"✏️ Отредактируй промпт или введи свой:\n\n"
        f"Текущий промпт:\n`{escape_md(current_prompt)}`"
    )
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад", callback_data="back_to_style_selection")]]),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_skip_prompt_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Пропуск ввода промпта для photo-to-photo."""
    logger.info(f"skip_prompt: Установлен стандартный промпт для user_id={user_id}")
    generation_type = context.user_data.get('generation_type', 'photo_to_photo')
    model_key = context.user_data.get('model_key', 'flux-trained')
    reference_image_url = context.user_data.get('reference_image_url')
    photo_path = context.user_data.get('photo_path')
    context.user_data['prompt'] = "copy reference style"
    context.user_data['generation_type'] = generation_type
    context.user_data['model_key'] = model_key
    if reference_image_url:
        context.user_data['reference_image_url'] = reference_image_url
    if photo_path:
        context.user_data['photo_path'] = photo_path
    logger.info(f"  Сохранены данные: generation_type={generation_type}, model_key={model_key}")
    await send_message_with_fallback(
        context.bot, user_id,
        escape_md("✅ Использую стандартный промпт. Выбери соотношение сторон:"),
        update_or_query=query,
        parse_mode=ParseMode.MARKDOWN_V2
    )
    await ask_for_aspect_ratio_callback(query, context)

async def handle_aspect_ratio_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, callback_data: str) -> None:
    """Обработка выбора соотношения сторон."""
    aspect_ratio = callback_data.replace("aspect_", "")
    context.user_data['aspect_ratio'] = aspect_ratio
    generation_type = context.user_data.get('generation_type', 'unknown')
    prompt = context.user_data.get('prompt', 'Не указан')
    generation_type_display = {
        'with_avatar': 'Фотосессия с аватаром',
        'photo_to_photo': 'Фото по референсу',
        'ai_video': 'AI-видео (Kling 1.6)',
        'ai_video_v2': 'AI-видео (Kling 2.0)',
        'prompt_assist': 'С помощником AI'
    }.get(generation_type, generation_type)
    prompt_source = ""
    selected_gender = context.user_data.get('selected_gender')
    current_style_set = context.user_data.get('current_style_set')
    if current_style_set == 'new_male_avatar':
        prompt_source = "👨 Мужской стиль"
        for style_key, style_name in NEW_MALE_AVATAR_STYLES.items():
            if new_male_avatar_prompts.get(style_key) == prompt:
                prompt_source += f": {style_name}"
                break
    elif current_style_set == 'new_female_avatar':
        prompt_source = "👩 Женский стиль"
        for style_key, style_name in NEW_FEMALE_AVATAR_STYLES.items():
            if new_female_avatar_prompts.get(style_key) == prompt:
                prompt_source += f": {style_name}"
                break
    elif current_style_set == 'generic_avatar':
        prompt_source = "🎨 Общий стиль"
        for style_key, style_name in GENERATION_STYLES.items():
            if style_prompts.get(style_key) == prompt:
                prompt_source += f": {style_name}"
                break
    if context.user_data.get('came_from_custom_prompt'):
        if context.user_data.get('user_input_for_llama'):
            prompt_source = "🤖 Промпт от AI-помощника"
        else:
            prompt_source = "✍️ Свой промпт"
    prompt_preview = prompt[:150] + '...' if len(prompt) > 150 else prompt
    confirm_text_parts = [
        f"📋 Проверь параметры генерации:\n\n",
        f"🎨 Тип: {escape_md(generation_type_display)}\n"
    ]
    if prompt_source:
        confirm_text_parts.append(f"📝 Выбор: {escape_md(prompt_source)}\n")
    confirm_text_parts.extend([
        f"📐 Формат: {escape_md(aspect_ratio)}\n",
        f"\n💭 Промпт: _{escape_md(prompt_preview)}_\n\n",
        f"Всё верно?"
    ])
    confirm_text = "".join(confirm_text_parts)
    await send_message_with_fallback(
        context.bot, user_id, confirm_text, update_or_query=query,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("✅ Да, генерировать!", callback_data="confirm_generation")],
            [InlineKeyboardButton("🔙 Изменить", callback_data="back_to_style_selection")]
        ]),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_aspect_ratio_info_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Информация о соотношениях сторон."""
    text = (
        "📐 Соотношения сторон\n\n"
        "📱 Квадратные: идеально для соцсетей\n"
        "🖥️ Горизонтальные: для широких кадров\n"
        "📲 Вертикальные: для портретов и Stories\n\n"
        "💡 Выберите подходящий формат в зависимости от того, где планируете использовать изображение."
    )
    keyboard = InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 К выбору формата", callback_data="back_to_aspect_selection")],
        [InlineKeyboardButton("🏠 Главное меню", callback_data="back_to_menu")]
    ])
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=keyboard, parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_back_to_aspect_selection_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Возврат к выбору соотношения сторон."""
    await ask_for_aspect_ratio_callback(query, context)

async def handle_back_to_style_selection_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Возврат к выбору стиля."""
    current_style_set = context.user_data.get('current_style_set', 'generic_avatar')
    if current_style_set == 'new_male_avatar':
        await handle_style_selection_callback(query, context, user_id, "select_new_male_avatar_styles")
    elif current_style_set == 'new_female_avatar':
        await handle_style_selection_callback(query, context, user_id, "select_new_female_avatar_styles")
    else:
        await handle_style_selection_callback(query, context, user_id, "select_generic_avatar_styles")

async def handle_confirm_generation_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, update: Update) -> None:
    """Обработка подтверждения генерации."""
    generation_type = context.user_data.get('generation_type')
    if generation_type == 'admin_with_user_avatar':
        context.user_data['generation_type'] = 'with_avatar'
        generation_type = 'with_avatar'
        logger.info(f"Изменен тип генерации с 'admin_with_user_avatar' на 'with_avatar' для админской генерации")
    if not context.user_data.get('model_key'):
        if generation_type in ['with_avatar', 'photo_to_photo']:
            context.user_data['model_key'] = 'flux-trained'
        elif generation_type in ['ai_video', 'ai_video_v2']:
            from config import GENERATION_TYPE_TO_MODEL_KEY
            model_key = None
            for gt, mk in GENERATION_TYPE_TO_MODEL_KEY.items():
                if generation_type == gt:
                    for mk_candidate, model_config in IMAGE_GENERATION_MODELS.items():
                        if model_config['id'] == mk:
                            model_key = mk_candidate
                            break
                    break
            context.user_data['model_key'] = model_key or ('kwaivgi/kling-v1.6-pro' if generation_type == 'ai_video' else 'kwaivgi/kling-v2.0')
        else:
            context.user_data['model_key'] = 'flux-trained'
        logger.info(f"Установлен model_key='{context.user_data['model_key']}' для generation_type='{generation_type}'")
    if generation_type == 'photo_to_photo':
        required_fields = ['reference_image_url', 'prompt', 'aspect_ratio']
        missing_fields = [f for f in required_fields if not context.user_data.get(f)]
        if missing_fields:
            logger.error(f"Отсутствуют поля для photo_to_photo: {missing_fields}")
            await send_message_with_fallback(
                context.bot, user_id,
                escape_md(f"❌ Ошибка: отсутствуют данные. Начните заново через меню."),
                update_or_query=query,
                reply_markup=await create_generate_menu_keyboard(),
                parse_mode=ParseMode.MARKDOWN_V2
            )
            return
        reference_url = context.user_data.get('reference_image_url')
        if not reference_url or not reference_url.startswith('http'):
            logger.error(f"Некорректный reference_image_url: {reference_url}")
            await send_message_with_fallback(
                context.bot, user_id,
                escape_md("❌ Ошибка: референсное изображение не загружено. Попробуйте снова."),
                update_or_query=query,
                reply_markup=await create_generate_menu_keyboard(),
                parse_mode=ParseMode.MARKDOWN_V2
            )
            return
    logger.info(f"Запуск генерации для user_id={user_id}, generation_type={generation_type}, "
                f"model_key={context.user_data.get('model_key')}")
    logger.info(f"Доступные данные в контексте: {list(context.user_data.keys())}")
    logger.info(f"prompt: {context.user_data.get('prompt', 'НЕТ')}")
    logger.info(f"aspect_ratio: {context.user_data.get('aspect_ratio', 'НЕТ')}")
    logger.info(f"generation_type: {context.user_data.get('generation_type', 'НЕТ')}")
    logger.info(f"model_key: {context.user_data.get('model_key', 'НЕТ')}")
    if generation_type == 'photo_to_photo':
        logger.info(f"reference_image_url: {context.user_data.get('reference_image_url', 'НЕТ')}")
        logger.info(f"photo_path: {context.user_data.get('photo_path', 'НЕТ')}")
    try:
        if generation_type in ['with_avatar', 'photo_to_photo']:
            await generate_image(update, context, num_outputs=2)
        elif generation_type in ['ai_video', 'ai_video_v2']:
            await handle_generate_video(update, context)
        else:
            await send_message_with_fallback(
                context.bot, user_id,
                escape_md("❌ Неизвестный тип генерации. Попробуйте снова."),
                update_or_query=query,
                reply_markup=await create_generate_menu_keyboard(),
                parse_mode=ParseMode.MARKDOWN_V2
            )
            logger.error(f"Неизвестный тип генерации: {generation_type}")
            return
    except Exception as e:
        logger.error(f"Ошибка в confirm_generation: {e}", exc_info=True)
        await send_message_with_fallback(
            context.bot, user_id,
            escape_md("❌ Произошла ошибка. Попробуйте еще раз."),
            update_or_query=query,
            reply_markup=await create_generate_menu_keyboard(),
            parse_mode=ParseMode.MARKDOWN_V2
        )

async def handle_rating_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, callback_data: str) -> None:
    """Обработка оценки результата."""
    rating = int(callback_data.split('_')[1])
    generation_type = context.user_data.get('generation_type', 'unknown')
    model_key = context.user_data.get('model_key', 'unknown')
    await add_rating(user_id, generation_type, model_key, rating)
    await safe_answer_callback(query, f"Спасибо за оценку {rating} ⭐!", show_alert=True)
    await send_message_with_fallback(
        context.bot, user_id,
        escape_md(f"Спасибо за оценку {rating} ⭐! Твой отзыв поможет нам стать лучше."),
        update_or_query=query,
        reply_markup=await create_main_menu_keyboard(user_id),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_user_profile_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Показ личного кабинета."""
    await delete_all_videos(context, user_id)
    reset_generation_context(context, "user_profile")
    subscription_data = await check_subscription(user_id)
    if not subscription_data or len(subscription_data) < 9:
        await send_message_with_fallback(
            context.bot, user_id,
            escape_md("❌ Ошибка получения данных профиля. Попробуйте позже."),
            update_or_query=query,
            reply_markup=await create_main_menu_keyboard(user_id),
            parse_mode=ParseMode.MARKDOWN_V2
        )
        return
    generations_left, avatar_left = subscription_data[0], subscription_data[1]
    text = (
        f"👤 Личный кабинет\n\n"
        f"💰 Баланс: {generations_left} фото, {avatar_left} аватар{'ов' if avatar_left != 1 else ''}"
    )
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=await create_user_profile_keyboard(user_id),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_check_subscription_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Проверка подписки."""
    subscription_data = await check_subscription(user_id)
    if not subscription_data or len(subscription_data) < 9:
        await safe_answer_callback(query, "❌ Ошибка получения данных", show_alert=True)
        return
    generations_left, avatar_left, _, username, _, _, email, _, _ = subscription_data
    email_text = f"\n📧 Email: {email}" if email else ""
    text = (
        f"💳 Твоя подписка:\n\n"
        f"📸 Фото на балансе: {generations_left}\n"
        f"👤 Аватары на балансе: {avatar_left}"
        f"{email_text}\n\n"
        f"_Фото тратятся на генерацию изображений и видео._\n"
        f"_Аватары нужны для создания персональных моделей._"
    )
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("💳 Пополнить баланс", callback_data="subscribe")],
            [InlineKeyboardButton("🔙 В личный кабинет", callback_data="user_profile")]
        ]),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_user_stats_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Показ статистики пользователя."""
    logger.debug(f"handle_user_stats: user_id={user_id}")
    try:
        gen_stats = await get_user_generation_stats(user_id)
        logger.debug(f"gen_stats для user_id={user_id}: {gen_stats}")
    except Exception as e:
        logger.error(f"Ошибка получения gen_stats для user_id={user_id}: {e}", exc_info=True)
        gen_stats = {}
    try:
        payments = await get_user_payments(user_id)
        total_spent = sum(p[2] for p in payments if p[2] is not None)
        logger.debug(f"payments для user_id={user_id}: {len(payments)} платежей, total_spent={total_spent}")
    except Exception as e:
        logger.error(f"Ошибка получения payments для user_id={user_id}: {e}", exc_info=True)
        payments = []
        total_spent = 0.0
    try:
        async with aiosqlite.connect('users.db') as conn:
            conn.row_factory = aiosqlite.Row
            c = await conn.cursor()
            await c.execute("SELECT referred_id, status, completed_at FROM referrals WHERE referrer_id = ?", (user_id,))
            my_referrals = await c.fetchall()
        logger.debug(f"Найдено {len(my_referrals)} рефералов для user_id={user_id}")
    except Exception as e:
        logger.error(f"Ошибка получения рефералов для user_id={user_id}: {e}", exc_info=True)
        my_referrals = []
    active_referrals = 0
    total_bonuses = 0
    for ref in my_referrals:
        ref_user_id = ref['referred_id']
        ref_status = ref['status']
        ref_data = await check_subscription(ref_user_id)
        has_purchased = ref_status == 'completed' or (ref_data and len(ref_data) > 5 and not bool(ref_data[5]))
        if has_purchased:
            active_referrals += 1
            total_bonuses += 5
    stats_text = escape_md("📊 Твоя статистика:\n\n")
    if gen_stats:
        stats_text += escape_md("Генерации:\n")
        type_names = {
            'with_avatar': 'Фото с аватаром',
            'photo_to_photo': 'Фото по референсу',
            'ai_video': 'AI-видео (1.6)',
            'ai_video_v2': 'AI-видео (2.0)',
            'train_flux': 'Обучение аватаров',
            'prompt_assist': 'Помощь с промптами'
        }
        for gen_type, count in gen_stats.items():
            type_name = type_names.get(gen_type, gen_type)
            stats_text += escape_md(f"  • {type_name}: {count}\n")
    else:
        stats_text += escape_md("_Ты еще ничего не генерировал_\n")
    stats_text += escape_md(f"\n💵 Всего потрачено: {total_spent:.2f} RUB\n")
    stats_text += escape_md(f"💳 Всего покупок: {len(payments)}\n")
    stats_text += escape_md(f"👥 Рефералов (с покупкой): {active_referrals}\n")
    stats_text += escape_md(f"🎁 Бонусных фото за рефералов: {total_bonuses}\n")
    bot_username = context.bot.username
    stats_text += escape_md(f"\n🔗 Твоя реферальная ссылка:\n`t.me/{bot_username}?start=ref_{user_id}`")
    await send_message_with_fallback(
        context.bot, user_id, stats_text, update_or_query=query,
        reply_markup=await create_referral_keyboard(user_id, bot_username),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_subscribe_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Показ тарифов."""
    await delete_all_videos(context, user_id)
    subscription_data = await check_subscription(user_id)
    first_purchase = bool(subscription_data[5]) if subscription_data and len(subscription_data) > 5 else True
    text = (
        "🔥 Горячий выбор для идеальных фото!\n\n"
        "Хочешь крутые кадры без лишних хлопот? "
        "Выбирай выгодный пакет и получай фото в один клик!\n\n"
        "💎 **НАШИ ПАКЕТЫ:**\n"
        "📸 399₽ за 10 фото\n"
        "📸 599₽ за 30 фото\n"
        "📸 1199₽ за 70 фото\n"
        "📸 3119₽ за 170 фото + 1 аватар\n"
        "📸 4599₽ за 250 фото + 1 аватар\n"
        "👤 690₽ за 1 аватар\n\n"
    )
    if first_purchase:
        text += "🎁 **При первой покупке к любому купленному тарифу впервые 1 Аватар в подарок!**\n\n"
    text += "Выбирай свой пакет и начинай творить! 🚀"
    keyboard = [
        [InlineKeyboardButton("📸 10 фото - 399₽", callback_data="pay_399")],
        [InlineKeyboardButton("📸 30 фото - 599₽", callback_data="pay_599")],
        [InlineKeyboardButton("📸 70 фото - 1199₽", callback_data="pay_1199")],
        [InlineKeyboardButton("📸 170 фото + аватар - 3119₽", callback_data="pay_3119")],
        [InlineKeyboardButton("📸 250 фото + аватар - 4599₽", callback_data="pay_4599")],
        [InlineKeyboardButton("👤 1 аватар - 690₽", callback_data="pay_690")],
        [InlineKeyboardButton("ℹ️ Информация о тарифах", callback_data="tariff_info")],
        [InlineKeyboardButton("🔙 Главное меню", callback_data="back_to_menu")]
    ]
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=InlineKeyboardMarkup(keyboard),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_payment_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, callback_data: str) -> None:
    """Обработка выбора тарифа для оплаты."""
    amount_str = callback_data.replace("pay_", "")
    tariff_key = None
    for key, details in TARIFFS.items():
        if str(int(details["amount"])) == amount_str:
            tariff_key = key
            break
    if not tariff_key:
        await safe_answer_callback(query, "❌ Неверный тариф", show_alert=True)
        return
    tariff = TARIFFS[tariff_key]
    amount = tariff["amount"]
    description = tariff["display"]
    context.user_data['payment_amount'] = amount
    context.user_data['payment_description'] = description
    context.user_data['payment_tariff_key'] = tariff_key
    subscription_data = await check_subscription(user_id)
    email = subscription_data[6] if subscription_data and len(subscription_data) > 6 else None
    if email:
        context.user_data['email'] = email
        try:
            bot_username = context.bot.username
            payment_url = await create_payment_link(user_id, email, amount, description, bot_username)
            is_first_purchase = bool(subscription_data[5]) if subscription_data and len(subscription_data) > 5 else True
            bonus_text = " (+ 1 аватар в подарок!)" if is_first_purchase and tariff.get("photos", 0) > 0 else ""
            payment_text = (
                f"💳 Оплата пакета\n"
                f"✨ Вы выбрали: {escape_md(description)}{escape_md(bonus_text)}\n"
                f"💰 Сумма: {amount:.2f} RUB\n\n"
                f"🔗 [Нажмите здесь для безопасной оплаты через YooKassa]({payment_url})\n\n"
                f"_После успешной оплаты ресурсы будут начислены автоматически._"
            )
            await send_message_with_fallback(
                context.bot, user_id, payment_text, update_or_query=query,
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад к пакетам", callback_data="subscribe")]]),
                parse_mode=ParseMode.MARKDOWN_V2
            )
        except Exception as e:
            logger.error(f"Ошибка создания платежной ссылки: {e}")
            await send_message_with_fallback(
                context.bot, user_id,
                escape_md(f"❌ Ошибка создания платежной ссылки: {str(e)}"),
                update_or_query=query,
                reply_markup=await create_subscription_keyboard(),
                parse_mode=ParseMode.MARKDOWN_V2
            )
    else:
        context.user_data['awaiting_email'] = True
        await send_message_with_fallback(
            context.bot, user_id,
            escape_md(f"📧 Для оформления покупки \"{description}\" ({amount:.2f} RUB) введите ваш email:"),
            update_or_query=query,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад к пакетам", callback_data="subscribe")]]),
            parse_mode=ParseMode.MARKDOWN_V2
        )

async def handle_my_avatars_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Показ аватаров пользователя."""
    await delete_all_videos(context, user_id)
    reset_generation_context(context, "my_avatars")
    text = escape_md("👥 Мои аватары\n\nЗдесь ты можешь выбрать активный аватар или создать новый.")
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=await create_avatar_selection_keyboard(user_id),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_select_avatar_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, callback_data: str) -> None:
    """Выбор активного аватара."""
    avatar_id = int(callback_data.split('_')[2])
    await update_resources(user_id, "set_active_avatar", amount=avatar_id)
    await safe_answer_callback(query, "✅ Аватар активирован!", show_alert=True)
    await handle_my_avatars_callback(query, context, user_id)

async def handle_train_flux_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Начало обучения нового аватара."""
    if not await check_resources(context, user_id, required_avatars=1):
        return
    reset_generation_context(context, "train_flux")
    context.user_data['training_step'] = 'upload_photos'
    context.user_data['training_photos'] = []
    text = (
        "🎨 СОЗДАНИЕ ВАШЕГО-АВАТАРА\n\n"
        "Для создания высококачественного аватара мне нужно минимум 10 твоих фотографий (оптимально 15-20) с АКЦЕНТОМ на лицо. "
        "Каждая фотография должна быть четкой и профессиональной, чтобы PixelPie точно воспроизвел ваши черты.\n\n"
        "📸 РЕКОМЕНДАЦИИ ДЛЯ ИДЕАЛЬНОГО РЕЗУЛЬТАТА:\n"
        "• ФОТОГРАФИИ ДОЛЖНЫ БЫТЬ ПРЯМЫМИ, ЧЕТКИМИ, БЕЗ ИСКАЖЕНИЙ И РАЗМЫТИЯ. Используй камеру с высоким разрешением.\n"
        "• Снимай в правильных ракурсах: Лицо должно быть полностью видно, без обрезки.\n"
        "• Используй разнообразное освещение: дневной свет, золотой час, мягкий студийный свет. ИЗБЕГАЙ ТЕМНЫХ ТЕНЕЙ И ПЕРЕСВЕТОВ.\n"
        "• Фон должен быть чистым, без лишних объектов (мебель, растения, животные). НЕ ДОПУСКАЮТСЯ ЗЕРКАЛА И ОТРАЖЕНИЯ.\n"
        "• Снимай только себя. ГРУППОВЫЕ ФОТО ИЛИ ФОТО С ДРУГИМИ ЛЮДЬМИ НЕ ПОДХОДЯТ.\n"
        "• НЕ ИСПОЛЬЗУЙ ОЧКИ, ШЛЯПЫ, МАСКИ ИЛИ ДРУГИЕ АКСЕССУАРЫ, закрывающие лицо. Макияж должен быть минимальным.\n"
        "• Выражение лица: нейтральное или легкая улыбка. ИЗБЕГАЙ КРИВЛЯНИЙ ИЛИ ЭКСТРЕМАЛЬНЫХ ЭМОЦИЙ.\n"
        "• Чем больше разнообразных фотографий (ракурсы, освещение, фон), тем точнее будет аватар.\n\n"
        "⚠️ ВАЖНО: Каждая фотография должна быть хорошего качества, без фильтров, цифрового шума или артефактов. "
        "Фотографии с низким разрешением, искажениями или посторонними объектами будут влиять на КАЧЕСТВО АВАТАРА.\n\n"
        "📤 Начинай загружать фотографии! Я проверю и сообщу, когда будет достаточно."
    )
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("❌ Отмена", callback_data="user_profile")]]),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_continue_upload_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int) -> None:
    """Продолжение загрузки фото."""
    photo_count = len(context.user_data.get('training_photos', []))
    text = escape_md(f"📸 Загружено {photo_count} фото. Продолжай загружать или нажми \"Начать обучение\".")
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=await create_training_keyboard(user_id, photo_count),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_start_training_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, update: Update) -> None:
    """Переход к вводу имени аватара."""
    photo_count = len(context.user_data.get('training_photos', []))
    if photo_count < 10:
        await safe_answer_callback(query, f"Нужно минимум 10 фото! Сейчас {photo_count}.", show_alert=True)
        return
    context.user_data['training_step'] = 'enter_avatar_name'
    text = (
        f"✅ Отлично! Загружено {photo_count} фото.\n\n"
        f"🏷 Теперь Придумайте Имя или Название для Вашего Аватара"
    )
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад к загрузке фото", callback_data="continue_upload")]]),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_confirm_start_training_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, update: Update):
    """Запуск обучения аватара."""
    await start_training(update, context)

async def handle_back_to_avatar_name_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int):
    """Возврат к вводу имени аватара."""
    context.user_data['training_step'] = 'enter_avatar_name'
    photo_count = len(context.user_data.get('training_photos', []))
    text = (
        f"🏷 Придумай имя для своего аватара (например: \"Мой стиль\", \"Бизнес-образ\").\n"
        f"У тебя загружено {photo_count} фото."
    )
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=query,
        reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 Назад к загрузке фото", callback_data="continue_upload")]]),
        parse_mode=ParseMode.MARKDOWN_V2
    )

async def handle_use_suggested_trigger(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, callback_data: str):
    """Использование предложенного триггер-слова."""
    trigger_word = callback_data.replace("use_suggested_trigger_", "")
    context.user_data['trigger_word'] = trigger_word
    context.user_data['training_step'] = 'confirm_training'
    from handlers.messages import handle_trigger_word_input
    await handle_trigger_word_input(query, context, trigger_word)

async def handle_confirm_photo_quality_callback(query, context: ContextTypes.DEFAULT_TYPE, user_id: int, update: Update):
    """Подтверждение качества фото перед обучением."""
    logger.debug(f"handle_confirm_photo_quality_callback: user_id={user_id}, context.user_data={context.user_data}")

    # Проверка данных
    avatar_name = context.user_data.get('avatar_name', 'Без имени')
    training_photos = context.user_data.get('training_photos', [])
    photo_count = len(training_photos)

    if photo_count < 10:
        logger.warning(f"Недостаточно фото для user_id={user_id}: {photo_count}")
        await send_message_with_fallback(
            context.bot, user_id,
            safe_escape_markdown(f"❌ Недостаточно фото для обучения. Загружено {photo_count}, требуется минимум 10."),
            update_or_query=query,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 К загрузке фото", callback_data="continue_upload")]]),
            parse_mode=ParseMode.MARKDOWN_V2
        )
        return

    if not avatar_name or avatar_name == 'Без имени':
        logger.warning(f"Отсутствует имя аватара для user_id={user_id}")
        await send_message_with_fallback(
            context.bot, user_id,
            safe_escape_markdown("❌ Ошибка: имя аватара не задано. Введите имя заново."),
            update_or_query=query,
            reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton("🔙 К вводу имени", callback_data="start_training")]]),
            parse_mode=ParseMode.MARKDOWN_V2
        )
        return

    final_confirm_text = (
        f"👍 Отлично! Давай проверим финальные данные:\n\n"
        f"👤 Имя аватара: {safe_escape_markdown(avatar_name)}\n"
        f"📸 Загружено фото: {photo_count} шт.\n\n"
        f"🚀 Все готово для запуска обучения!\n"
        f"⏱️ Это займет около 3-5 минут.\n"
        f"💎 Будет списан 1 аватар с твоего баланса.\n\n"
        f"Начинаем?"
    )

    logger.debug(f"Sending confirmation message to user_id={user_id}: {final_confirm_text[:100]}...")

    try:
        await asyncio.sleep(0.1)  # Задержка для избежания лимитов Telegram
        message = await send_message_with_fallback(
            context.bot, user_id, final_confirm_text, update_or_query=query,
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🚀 Начать обучение!", callback_data="confirm_start_training")],
                [InlineKeyboardButton("✏️ Изменить данные", callback_data="train_flux")]
            ]),
            parse_mode=ParseMode.MARKDOWN_V2
        )
        logger.info(f"Confirmation message sent successfully to user_id={user_id}, message_id={message.message_id}")
    except Exception as e:
        logger.error(f"Ошибка отправки сообщения для user_id={user_id}: {e}", exc_info=True)
        await send_message_with_fallback(
            context.bot, user_id,
            safe_escape_markdown("❌ Ошибка при подтверждении данных. Попробуйте снова."),
            update_or_query=query,
            reply_markup=await create_main_menu_keyboard(user_id),
            parse_mode=ParseMode.MARKDOWN_V2
        )

async def ask_for_aspect_ratio_callback(update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Запрос соотношения сторон."""
    user_id = update.effective_user.id if isinstance(update, Update) else update.from_user.id
    came_from_custom = context.user_data.get('came_from_custom_prompt', False)
    back_callback = "enter_custom_prompt_manual" if came_from_custom else "back_to_style_selection"
    text = escape_md("📐 Выбери соотношение сторон для изображения:")
    await send_message_with_fallback(
        context.bot, user_id, text, update_or_query=update,
        reply_markup=await create_aspect_ratio_keyboard(back_callback),
        parse_mode=ParseMode.MARKDOWN_V2
    )

user_callback_handler = CallbackQueryHandler(handle_user_callback, pattern="^(?!admin_)(?!user_)(?!payments_)(?!visualize_)(?!confirm_)(?!reset_)(?!broadcast_).*")

