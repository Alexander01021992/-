"""
Обработчики для функции "Фото Преображение"
PixelPie AI Bot - версия для aiogram
"""

from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, BufferedInputFile
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.enums import ParseMode
import logging
import os
import uuid
from datetime import datetime
import asyncio
import time
from typing import Optional

from generation.photo_transform import PhotoTransformGenerator
from generation.images import upload_image_to_replicate
from database import check_database_user, update_user_credits, is_user_blocked
from config import ADMIN_IDS
from handlers.utils import escape_message_parts

logger = logging.getLogger(__name__)

# Инициализация роутера
photo_transform_router = Router(name='photo_transform')

# Состояния FSM для процесса генерации
class PhotoTransformStates(StatesGroup):
    waiting_for_photo = State()
    choosing_style = State()
    choosing_aspect_ratio = State()  # Новое: Выбор соотношения сторон
    processing = State()

# Инициализация генератора (должен быть установлен при подключении роутера)
photo_generator: Optional[PhotoTransformGenerator] = None

def init_photo_generator(replicate_api_key: str):
    """Инициализация генератора фото"""
    global photo_generator
    photo_generator = PhotoTransformGenerator(replicate_api_key)

def get_progress_bar(percent: int) -> str:
    """
    Создает прогресс-бар из печенек
    
    Args:
        percent: Процент выполнения (0-100)
        
    Returns:
        Строка с прогресс-баром
    """
    total_cookies = 10
    filled = int(percent / 10)
    empty = total_cookies - filled
    
    bar = "🍪" * filled + "⚪" * empty
    return f"{bar} {percent}%"

# Новая функция: Асинхронное обновление прогресса
async def update_progress(progress_message: Message, state: FSMContext, expected_duration: int = 67):
    """
    Фоновая задача для динамического обновления прогресс-бара.
    
    Args:
        progress_message: Сообщение для редактирования.
        state: FSMContext для проверки состояния.
        expected_duration: Ожидаемое время в секундах (1 мин 7 сек по примеру).
    """
    start_time = time.time()
    while True:
        elapsed = time.time() - start_time
        percent = min(int((elapsed / expected_duration) * 100), 99)  # До 99%, чтобы 100% показать после успеха
        current_state = await state.get_state()
        if current_state != PhotoTransformStates.processing:  # Если состояние изменилось (успех/ошибка), выходим
            break
        
        progress_text = (
            f"⏳ Генерация в процессе...\n"
            f"{get_progress_bar(percent)} – Обработка фото нашей нейросетью...\n"
            f"Это займет около 1 минуты. Пожалуйста, подождите 😊"
        )
        try:
            await progress_message.edit_text(
                escape_message_parts(progress_text, version=2),
                parse_mode=ParseMode.MARKDOWN_V2
            )
        except Exception as e:
            logger.debug(f"Не удалось обновить прогресс: {e}")  # Не критично, продолжаем
            break
        
        await asyncio.sleep(5)  # Обновляем каждые 5 секунд для плавности

# Обработчик callback для начала преображения
@photo_transform_router.callback_query(F.data == "photo_transform")
async def start_photo_transform(callback: CallbackQuery, state: FSMContext):
    """Начало процесса преображения фото"""
    try:
        await callback.answer()
        user_id = callback.from_user.id
        
        # Проверка блокировки
        if await is_user_blocked(user_id):
            await callback.message.answer(
                escape_message_parts("🚫 Ваш аккаунт заблокирован. Обратитесь в поддержку: @AXIDI_Help", version=2),
                parse_mode=ParseMode.MARKDOWN_V2
            )
            return
        
        # Проверка баланса
        user_data = await check_database_user(user_id)
        if not user_data or user_data[0] <= 0:  # user_data[0] - это generations_left (печеньки)
            await callback.message.answer(
                escape_message_parts("❌ У вас недостаточно печенек для генерации. Пополните баланс!", version=2),
                parse_mode=ParseMode.MARKDOWN_V2,
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="💳 Купить пакет", callback_data="subscribe")],
                    [InlineKeyboardButton(text="🔙 Главное меню", callback_data="back_to_menu")]
                ])
            )
            return
        
        # Очищаем предыдущее состояние
        await state.clear()
        
        # Приветственное сообщение
        welcome_text = """🎭 Фото Преображение от PixelPie AI

Превратите ваше селфи в произведение искусства! 🎨

Просто отправьте одно фото, и наша нейросеть создаст уникальный образ в выбранном стиле.

Доступные стили:
▪️ Фотошоп 🤍 — Улучшение качества без изменений
▪️ Арт 🎨 — Иллюстрация в авторском стиле
▪️ Кино 🎬 — Кадр из художественного фильма
▪️ Портрет 🧠 — Глубокий психологический образ
▪️ Фантастика ⚡ — Неон, sci-fi, визуальный драйв
▪️ LEGO 🧱 — Превращение в минифигурку

📸 Отправьте ваше фото для начала!"""
        
        # Кнопка отмены
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="❌ Отменить", callback_data="transform_cancel")]
        ])
        
        await callback.message.answer(
            escape_message_parts(welcome_text, version=2),
            parse_mode=ParseMode.MARKDOWN_V2,
            reply_markup=keyboard
        )
        
        # Устанавливаем состояние ожидания фото
        await state.set_state(PhotoTransformStates.waiting_for_photo)
        
    except Exception as e:
        logger.error(f"Ошибка при старте photo transform: {str(e)}")
        await callback.message.answer(
            escape_message_parts("❌ Произошла ошибка. Попробуйте позже.", version=2),
            parse_mode=ParseMode.MARKDOWN_V2
        )

# Обработчик получения фото
@photo_transform_router.message(PhotoTransformStates.waiting_for_photo, F.photo)
async def handle_photo(message: Message, state: FSMContext):
    """Обработка полученного фото"""
    try:
        user_id = message.from_user.id
        
        # Получаем файл фото
        photo = message.photo[-1]  # Берем самое большое разрешение
        file_id = photo.file_id
        
        # Сохраняем file_id в состоянии
        await state.update_data(photo_file_id=file_id)
        
        # Показываем выбор стилей
        style_text = """✨ Отлично! Фото получено.

Теперь выберите стиль преображения:"""
        
        # Получаем клавиатуру со стилями
        keyboard_data = photo_generator.get_style_keyboard()
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=btn["text"], callback_data=btn["callback_data"]) 
             for btn in row]
            for row in keyboard_data
        ])
        
        await message.answer(
            escape_message_parts(style_text, version=2),
            parse_mode=ParseMode.MARKDOWN_V2,
            reply_markup=keyboard
        )
        
        # Переходим к выбору стиля
        await state.set_state(PhotoTransformStates.choosing_style)
        
    except Exception as e:
        logger.error(f"Ошибка при обработке фото: {str(e)}")
        await message.answer(
            escape_message_parts("❌ Ошибка при обработке фото. Попробуйте еще раз.", version=2),
            parse_mode=ParseMode.MARKDOWN_V2
        )
        await state.clear()

# Обработчик неправильного типа сообщения при ожидании фото
@photo_transform_router.message(PhotoTransformStates.waiting_for_photo)
async def handle_wrong_content(message: Message):
    """Обработка неправильного типа контента"""
    await message.answer(
        escape_message_parts(
            "📸 Пожалуйста, отправьте фото для преображения.\n\n"
            "Поддерживаются только изображения в формате JPG/PNG.",
            version=2
        ),
        parse_mode=ParseMode.MARKDOWN_V2
    )

# Обработчик выбора стиля (изменение: После выбора стиля переходим к выбору aspect_ratio)
@photo_transform_router.callback_query(PhotoTransformStates.choosing_style, F.data.startswith("transform_style:"))
async def handle_style_selection(callback: CallbackQuery, state: FSMContext):
    """Обработка выбора стиля и переход к выбору aspect_ratio"""
    try:
        await callback.answer()
        user_id = callback.from_user.id
        
        # Получаем выбранный стиль
        style = callback.data.split(":")[1]
        
        # Сохраняем стиль в состоянии
        await state.update_data(selected_style=style)
        
        # Показываем клавиатуру соотношения сторон
        aspect_text = """✨ Стиль выбран!

Теперь выберите соотношение сторон для генерации:"""
        
        keyboard_data = photo_generator.get_aspect_ratio_keyboard(style)
        keyboard = InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text=btn["text"], callback_data=btn["callback_data"]) 
             for btn in row]
            for row in keyboard_data
        ])
        
        await callback.message.edit_text(
            escape_message_parts(aspect_text, version=2),
            parse_mode=ParseMode.MARKDOWN_V2,
            reply_markup=keyboard
        )
        
        # Переходим к выбору aspect_ratio
        await state.set_state(PhotoTransformStates.choosing_aspect_ratio)
        
    except Exception as e:
        logger.error(f"Ошибка при выборе стиля: {str(e)}")
        await callback.message.edit_text(
            escape_message_parts("❌ Ошибка при выборе стиля. Начните заново.", version=2),
            parse_mode=ParseMode.MARKDOWN_V2
        )
        await state.clear()

# Новое: Обработчик выбора aspect_ratio и запуск генерации с фиксированным resolution=720p
@photo_transform_router.callback_query(PhotoTransformStates.choosing_aspect_ratio, F.data.startswith("transform_ratio:"))
async def handle_aspect_ratio_selection(callback: CallbackQuery, state: FSMContext):
    """Обработка выбора соотношения сторон и запуск генерации с фиксированным resolution=720p"""
    try:
        await callback.answer()
        user_id = callback.from_user.id
        bot = callback.bot
        
        # Получаем данные из callback (style:aspect_ratio)
        parts = callback.data.split(":")
        style = parts[1]
        aspect_ratio = parts[2]
        
        # Фиксированное разрешение
        resolution = "720p"
        
        # Получаем данные из состояния
        data = await state.get_data()
        photo_file_id = data.get("photo_file_id")
        
        if not photo_file_id:
            await callback.message.edit_text(
                escape_message_parts("❌ Ошибка: фото не найдено. Начните заново.", version=2),
                parse_mode=ParseMode.MARKDOWN_V2
            )
            await state.clear()
            return
        
        # Показываем описание стиля (для последовательности)
        style_description = photo_generator.get_style_description(style)
        
        # Первое сообщение - описание стиля
        await callback.message.edit_text(
            escape_message_parts(style_description, version=2),
            parse_mode=ParseMode.MARKDOWN_V2
        )
        
        # Ждем немного перед вторым сообщением
        await asyncio.sleep(1)
        
        # Второе сообщение - начало генерации с начальным текстом
        start_text = (
            "⏳ Начинаю генерацию...\n"
            "Это займет 1 минуту. Пожалуйста, подождите 😊"
        )
        progress_message = await callback.message.answer(
            escape_message_parts(start_text, version=2),
            parse_mode=ParseMode.MARKDOWN_V2
        )
        
        # Устанавливаем состояние обработки
        await state.set_state(PhotoTransformStates.processing)
        await state.update_data(selected_style=style, selected_aspect_ratio=aspect_ratio, selected_resolution=resolution)
        
        # Добавили динамический прогресс-бар
        progress_task = asyncio.create_task(update_progress(progress_message, state))
        
        start_time = time.time()  # Для расчёта реального времени
        
        try:
            # Получаем файл от Telegram
            file = await bot.get_file(photo_file_id)
            
            # Создаем директорию для временных файлов
            uploads_dir = f"generated/{user_id}"
            os.makedirs(uploads_dir, exist_ok=True)
            
            # Сохраняем файл локально
            photo_path = os.path.join(uploads_dir, f"transform_{uuid.uuid4()}.jpg")
            await bot.download_file(file.file_path, photo_path)
            
            # Загружаем на Replicate
            logger.info("Загрузка изображения на Replicate...")
            public_url = await upload_image_to_replicate(photo_path)
            
            # Сохраняем путь для очистки
            await state.update_data(transform_photo_path=photo_path)
            
            # Запускаем генерацию с новыми параметрами
            logger.info(f"Запуск генерации для пользователя {user_id} в стиле {style}")
            result = await photo_generator.generate_image(
                image_url=public_url,
                style=style,
                user_id=user_id,
                aspect_ratio=aspect_ratio,
                resolution=resolution
            )
            
            # Останавливаем прогресс после генерации
            progress_task.cancel()
            elapsed_time = time.time() - start_time
            min_sec = f"{int(elapsed_time // 60)} мин {int(elapsed_time % 60)} сек"
            
            if result["success"]:
                # Обновляем сообщение на 100% с реальным временем
                try:
                    await progress_message.edit_text(
                        escape_message_parts(
                            f"🎨 Генерация завершена!\n\n{get_progress_bar(100)}\nЗаняло {min_sec}.",
                            version=2
                        ),
                        parse_mode=ParseMode.MARKDOWN_V2
                    )
                    await asyncio.sleep(1)  # Показываем 100% на секунду
                except:
                    pass
                
                # Скачиваем результат
                logger.info(f"Результат генерации получен: success=True")
                result_url = result.get('result_url')
                logger.info(f"URL результата (до преобразования): {result_url}")
                logger.info(f"Тип result_url: {type(result_url)}")
                
                # Преобразуем FileOutput в строку
                if not isinstance(result_url, str):
                    result_url = str(result_url)
                    logger.info(f"Преобразовали в строку: {result_url}")
                
                try:
                    result_image = await photo_generator.download_image(result_url)
                    logger.info(f"Изображение скачано, размер: {len(result_image)} байт")
                except Exception as e:
                    logger.error(f"Ошибка при скачивании результата: {str(e)}")
                    raise
                
                # Списываем фото
                await update_user_credits(user_id, "decrement_photo", amount=1)
                logger.info(f"Списано 1 фото для генерации в стиле {style} для пользователя {user_id}")
                
                # Отправляем результат
                caption = f"""✨ Готово!

Ваше фото в стиле **{result['style_name']}**

🎨 Сгенерировано с помощью PixelPie AI
🕐 Время: {datetime.now().strftime('%H:%M')}

Хотите попробовать другой стиль? Отправьте новое фото!"""
                
                # Кнопки для дополнительных действий
                keyboard = InlineKeyboardMarkup(inline_keyboard=[
                    [
                        InlineKeyboardButton(text="🎭 Новое преображение", callback_data="photo_transform"),
                        InlineKeyboardButton(text="📱 В главное меню", callback_data="back_to_menu")
                    ]
                ])
                
                # Обернули bytes в BufferedInputFile для корректной отправки
                if not isinstance(result_image, bytes):
                    raise ValueError("result_image must be bytes")
                photo_input = BufferedInputFile(result_image, filename="transformed.png")
                logger.debug(f"Подготовка к отправке: тип photo_input={type(photo_input)}")
                
                # Отправляем фото с результатом
                await bot.send_photo(
                    chat_id=user_id,
                    photo=photo_input,
                    caption=escape_message_parts(caption, version=2),
                    parse_mode=ParseMode.MARKDOWN_V2,
                    reply_markup=keyboard
                )
                
                # Удаляем сообщение о процессе и описание стиля
                try:
                    await callback.message.delete()  # Удаляем сообщение с описанием стиля
                except:
                    pass
                try:
                    await progress_message.delete()  # Удаляем сообщение с прогрессом
                except:
                    pass
                
                # Логируем успешную генерацию
                logger.info(f"Успешная генерация для пользователя {user_id} в стиле {style}")
                
                # Удаляем временные файлы
                try:
                    if os.path.exists(photo_path):
                        os.remove(photo_path)
                except Exception as e:
                    logger.debug(f"Не удалось удалить временный файл: {e}")
                
            else:
                # Обработка ошибки
                error_text = f"""❌ Ошибка генерации

К сожалению, не удалось создать изображение.
Ошибка: {result.get('error', 'Неизвестная ошибка')}

Печенька возвращена на баланс 🍪
Попробуйте еще раз или выберите другой стиль."""
                
                keyboard = InlineKeyboardMarkup(inline_keyboard=[
                    [
                        InlineKeyboardButton(text="🔄 Попробовать снова", callback_data="photo_transform"),
                        InlineKeyboardButton(text="📱 В главное меню", callback_data="back_to_menu")
                    ]
                ])
                
                await callback.message.edit_text(
                    escape_message_parts(error_text, version=2),
                    parse_mode=ParseMode.MARKDOWN_V2,
                    reply_markup=keyboard
                )
                
                logger.error(f"Ошибка генерации для пользователя {user_id}: {result.get('error')}")
                
                # Удаляем временный файл при ошибке
                try:
                    if os.path.exists(photo_path):
                        os.remove(photo_path)
                except Exception as e:
                    logger.debug(f"Не удалось удалить временный файл: {e}")
                
                # Возвращаем печеньку при ошибке
                await update_user_credits(user_id, "increment_photo", amount=1)
                logger.info(f"Вернули 1 печеньку пользователю {user_id} после ошибки генерации")
            
        except Exception as e:
            # Останавливаем прогресс при ошибке
            if progress_task:
                progress_task.cancel()
            
            logger.error(f"Критическая ошибка при генерации: {str(e)}")
            
            # Удаляем сообщение с прогрессом
            if progress_message:
                try:
                    await progress_message.delete()
                except:
                    pass
            
            # Пытаемся удалить временный файл
            try:
                data = await state.get_data()
                photo_path = data.get('transform_photo_path')
                if photo_path and os.path.exists(photo_path):
                    os.remove(photo_path)
            except:
                pass
            
            # Возвращаем печеньку при критической ошибке
            try:
                await update_user_credits(user_id, "increment_photo", amount=1)
                logger.info(f"Вернули 1 печеньку пользователю {user_id} после критической ошибки")
            except:
                pass
            
            # Сообщение об ошибке
            await callback.message.edit_text(
                escape_message_parts(
                    "❌ Произошла критическая ошибка при генерации.\n\n"
                    "Печенька возвращена на баланс 🍪\n"
                    "Пожалуйста, попробуйте позже или обратитесь в поддержку.",
                    version=2
                ),
                parse_mode=ParseMode.MARKDOWN_V2,
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [
                        InlineKeyboardButton(text="🔄 Попробовать снова", callback_data="photo_transform"),
                        InlineKeyboardButton(text="📱 В главное меню", callback_data="back_to_menu")
                    ]
                ])
            )
        
        # Очищаем состояние
        await state.clear()
        
    except Exception as e:
        # Останавливаем прогресс при общей ошибке
        if 'progress_task' in locals() and progress_task:
            progress_task.cancel()
        
        logger.error(f"Общая ошибка в handle_aspect_ratio_selection: {str(e)}")
        
        # Пытаемся удалить progress_message
        if 'progress_message' in locals() and progress_message:
            try:
                await progress_message.delete()
            except:
                pass
        
        # Пытаемся вернуть печеньку
        try:
            await update_user_credits(user_id, "increment_photo", amount=1)
            logger.info(f"Вернули 1 печеньку пользователю {user_id} после общей ошибки")
        except:
            pass
        
        try:
            await callback.message.edit_text(
                escape_message_parts("❌ Произошла ошибка при генерации. Печенька возвращена 🍪", version=2),
                parse_mode=ParseMode.MARKDOWN_V2,
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="📱 В главное меню", callback_data="back_to_menu")]
                ])
            )
        except:
            # Если не удалось отредактировать, отправляем новое
            await callback.message.answer(
                escape_message_parts("❌ Произошла ошибка при генерации. Печенька возвращена 🍪", version=2),
                parse_mode=ParseMode.MARKDOWN_V2,
                reply_markup=InlineKeyboardMarkup(inline_keyboard=[
                    [InlineKeyboardButton(text="📱 В главное меню", callback_data="back_to_menu")]
                ])
            )
        
        await state.clear()

# Обработчик отмены
@photo_transform_router.callback_query(F.data == "transform_cancel")
async def handle_cancel(callback: CallbackQuery, state: FSMContext):
    """Обработка отмены операции"""
    await callback.answer("Операция отменена")
    await callback.message.edit_text(
        escape_message_parts(
            "❌ Операция отменена.\n\n"
            "Вы можете начать заново, нажав на кнопку «🎭 Фото Преображение» в главном меню.",
            version=2
        ),
        parse_mode=ParseMode.MARKDOWN_V2,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📱 В главное меню", callback_data="back_to_menu")]
        ])
    )
    await state.clear()

# Экспорт роутера
__all__ = ['photo_transform_router', 'init_photo_generator']